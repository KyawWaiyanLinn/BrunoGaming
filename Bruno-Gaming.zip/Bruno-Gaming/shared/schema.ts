import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const coinPackages = pgTable("coin_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: text("platform").notNull(), // 'iPhone', 'Android', 'Japan'
  coins: integer("coins").notNull(),
  price: integer("price").notNull(), // in Myanmar Kyat
  isActive: integer("is_active").default(1), // boolean as integer
});

export const orders = pgTable("orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerName: text("customer_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  gameAccountId: text("game_account_id").notNull(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes"),
  items: json("items").notNull(), // array of cart items
  totalAmount: integer("total_amount").notNull(),
  status: text("status").default("pending"), // 'pending', 'processing', 'completed', 'cancelled'
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCoinPackageSchema = createInsertSchema(coinPackages).omit({
  id: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

export type CoinPackage = typeof coinPackages.$inferSelect;
export type InsertCoinPackage = z.infer<typeof insertCoinPackageSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

// Cart item type for frontend
export const cartItemSchema = z.object({
  coins: z.number(),
  price: z.number(),
  platform: z.string(),
});

export type CartItem = z.infer<typeof cartItemSchema>;
