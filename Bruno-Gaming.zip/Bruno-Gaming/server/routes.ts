import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema, cartItemSchema } from "@shared/schema";
import { z } from "zod";

const createOrderRequestSchema = insertOrderSchema.extend({
  items: z.array(cartItemSchema),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all coin packages
  app.get("/api/coin-packages", async (req, res) => {
    try {
      const packages = await storage.getCoinPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coin packages" });
    }
  });

  // Get coin packages by platform
  app.get("/api/coin-packages/:platform", async (req, res) => {
    try {
      const { platform } = req.params;
      const packages = await storage.getCoinPackagesByPlatform(platform);
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coin packages" });
    }
  });

  // Create new order
  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = createOrderRequestSchema.parse(req.body);
      
      // Calculate total amount from items
      const totalAmount = validatedData.items.reduce((sum, item) => sum + item.price, 0);
      
      const order = await storage.createOrder({
        ...validatedData,
        totalAmount,
      });
      
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid order data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create order" });
      }
    }
  });

  // Get all orders (for admin)
  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Get specific order
  app.get("/api/orders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const order = await storage.getOrder(id);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  // Update order status
  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!status || !["pending", "processing", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const order = await storage.updateOrderStatus(id, status);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
