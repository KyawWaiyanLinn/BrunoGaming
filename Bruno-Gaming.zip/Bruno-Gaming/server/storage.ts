import { type CoinPackage, type InsertCoinPackage, type Order, type InsertOrder, coinPackages, orders } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Coin packages
  getCoinPackages(): Promise<CoinPackage[]>;
  getCoinPackagesByPlatform(platform: string): Promise<CoinPackage[]>;
  createCoinPackage(coinPackage: InsertCoinPackage): Promise<CoinPackage>;
  
  // Orders
  getOrder(id: string): Promise<Order | undefined>;
  getAllOrders(): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializePackages();
  }

  private async initializePackages() {
    // Check if packages already exist
    const existingPackages = await db.select().from(coinPackages).limit(1);
    if (existingPackages.length > 0) {
      return; // Packages already initialized
    }

    // iPhone packages from the design
    const iphonePackages = [
      { platform: "iPhone", coins: 300, price: 16000 },
      { platform: "iPhone", coins: 550, price: 23000 },
      { platform: "iPhone", coins: 750, price: 29000 },
      { platform: "iPhone", coins: 1040, price: 38000 },
      { platform: "iPhone", coins: 2130, price: 68000 },
      { platform: "iPhone", coins: 3250, price: 100000 },
      { platform: "iPhone", coins: 5700, price: 160000 },
      { platform: "iPhone", coins: 12800, price: 330000 },
    ];

    // Android packages from the design
    const androidPackages = [
      { platform: "Android", coins: 300, price: 17000 },
      { platform: "Android", coins: 550, price: 27000 },
      { platform: "Android", coins: 750, price: 35000 },
      { platform: "Android", coins: 1040, price: 48000 },
      { platform: "Android", coins: 2130, price: 86000 },
      { platform: "Android", coins: 3250, price: 128000 },
      { platform: "Android", coins: 5700, price: 206000 },
      { platform: "Android", coins: 12800, price: 412000 },
    ];

    // Japan Region packages from the design
    const japanPackages = [
      { platform: "Japan", coins: 137, price: 8000 },
      { platform: "Japan", coins: 315, price: 17000 },
      { platform: "Japan", coins: 578, price: 25800 },
      { platform: "Japan", coins: 788, price: 35000 },
      { platform: "Japan", coins: 1092, price: 47000 },
      { platform: "Japan", coins: 2237, price: 85000 },
      { platform: "Japan", coins: 3413, price: 126000 },
      { platform: "Japan", coins: 5985, price: 205000 },
      { platform: "Japan", coins: 13440, price: 425000 },
      { platform: "Japan", coins: 32200, price: 980000 },
    ];

    // Insert all packages into database
    const allPackages = [...iphonePackages, ...androidPackages, ...japanPackages];
    for (const pkg of allPackages) {
      await db.insert(coinPackages).values({
        ...pkg,
        isActive: 1,
      });
    }
  }

  async getCoinPackages(): Promise<CoinPackage[]> {
    return await db.select().from(coinPackages).where(eq(coinPackages.isActive, 1));
  }

  async getCoinPackagesByPlatform(platform: string): Promise<CoinPackage[]> {
    return await db.select()
      .from(coinPackages)
      .where(eq(coinPackages.platform, platform));
  }

  async createCoinPackage(insertPackage: InsertCoinPackage): Promise<CoinPackage> {
    const [coinPackage] = await db
      .insert(coinPackages)
      .values({
        ...insertPackage,
        isActive: insertPackage.isActive ?? 1,
      })
      .returning();
    return coinPackage;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async getAllOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(orders.createdAt);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values({
        ...insertOrder,
        status: insertOrder.status || "pending",
        notes: insertOrder.notes || null,
      })
      .returning();
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return order || undefined;
  }
}

export const storage = new DatabaseStorage();
