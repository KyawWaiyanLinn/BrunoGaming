import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X, Send } from "lucide-react";
import PaymentSuccessModal from "@/components/payment-success-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CartItem, insertOrderSchema } from "@shared/schema";
import { formatPrice, PAYMENT_METHODS } from "@/lib/coin-data";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  totalAmount: number;
  onOrderComplete: () => void;
}

const checkoutFormSchema = insertOrderSchema.extend({
  items: z.array(z.object({
    coins: z.number(),
    price: z.number(),
    platform: z.string(),
  })),
});

type CheckoutFormData = z.infer<typeof checkoutFormSchema>;

export default function CheckoutModal({ isOpen, onClose, cart, totalAmount, onOrderComplete }: CheckoutModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false);
  const [successOrder, setSuccessOrder] = useState<any>(null);

  const form = useForm<CheckoutFormData>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      customerName: "",
      phoneNumber: "",
      gameAccountId: "",
      paymentMethod: "",
      notes: "",
      items: cart,
      totalAmount: totalAmount,
      status: "pending",
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: CheckoutFormData) => {
      const response = await apiRequest("POST", "/api/orders", {
        ...data,
        items: cart,
        totalAmount: totalAmount,
      });
      return response.json();
    },
    onSuccess: (order) => {
      setSuccessOrder(order);
      setShowPaymentSuccess(true);
      onOrderComplete();
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Order Failed",
        description: "Failed to submit order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CheckoutFormData) => {
    createOrderMutation.mutate(data);
  };

  const handleClose = () => {
    if (!createOrderMutation.isPending) {
      onClose();
      form.reset();
      setShowPaymentSuccess(false);
      setSuccessOrder(null);
    }
  };

  const handlePaymentSuccessClose = () => {
    setShowPaymentSuccess(false);
    setSuccessOrder(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md w-full max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gaming-dark">
            Complete Your Order
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="customerName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Customer Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phoneNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input placeholder="09XXXXXXXXX" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="gameAccountId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>eFootball Account Email/ID</FormLabel>
                  <FormControl>
                    <Input placeholder="Your game account details" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Payment Method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {PAYMENT_METHODS.map((method) => (
                        <SelectItem key={method.value} value={method.value}>
                          {method.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Any special instructions..."
                      rows={3}
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Order Summary */}
            <div className="border-t pt-4">
              <h4 className="font-semibold mb-2">Order Summary:</h4>
              <div className="space-y-1 text-sm">
                {cart.map((item, index) => (
                  <div key={index} className="flex justify-between">
                    <span>{item.coins.toLocaleString()} {item.platform} Coins</span>
                    <span>{formatPrice(item.price)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center mt-2 pt-2 border-t font-semibold">
                <span>Total:</span>
                <span className="text-xl text-gaming-blue">
                  {formatPrice(totalAmount)}
                </span>
              </div>
            </div>

            <Button
              type="submit"
              disabled={createOrderMutation.isPending}
              className="w-full bg-gaming-gold hover:bg-yellow-500 text-gaming-dark font-bold"
            >
              {createOrderMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gaming-dark mr-2"></div>
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Submit Order
                </>
              )}
            </Button>
          </form>
        </Form>
      </DialogContent>

      {/* Payment Success Modal */}
      {showPaymentSuccess && successOrder && (
        <PaymentSuccessModal
          isOpen={showPaymentSuccess}
          onClose={handlePaymentSuccessClose}
          orderId={successOrder.id}
          totalAmount={successOrder.totalAmount}
          selectedPaymentMethod={successOrder.paymentMethod}
        />
      )}
    </Dialog>
  );
}
