import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Coins } from "lucide-react";
import { CoinPackage, CartItem } from "@shared/schema";
import { formatPrice, getPlatformColor, getPlatformIcon } from "@/lib/coin-data";
import { useToast } from "@/hooks/use-toast";

interface CoinPackagesProps {
  selectedPlatform: string;
  onPlatformChange: (platform: string) => void;
  onAddToCart: (item: CartItem) => void;
}

const platforms = [
  { key: "iPhone", label: "iPhone", icon: "fab fa-apple" },
  { key: "Android", label: "Android", icon: "fab fa-android" },
  { key: "Japan", label: "Japan Region", icon: "fas fa-flag" },
];

export default function CoinPackages({ selectedPlatform, onPlatformChange, onAddToCart }: CoinPackagesProps) {
  const { toast } = useToast();
  
  const { data: packages, isLoading, error } = useQuery<CoinPackage[]>({
    queryKey: ["/api/coin-packages", selectedPlatform],
    enabled: !!selectedPlatform,
  });

  const handleAddToCart = (pkg: CoinPackage) => {
    const cartItem: CartItem = {
      coins: pkg.coins,
      price: pkg.price,
      platform: pkg.platform,
    };
    
    onAddToCart(cartItem);
    
    toast({
      title: "Added to Cart",
      description: `${pkg.coins.toLocaleString()} ${pkg.platform} coins for ${formatPrice(pkg.price)}`,
    });
  };

  const platformColor = getPlatformColor(selectedPlatform);

  return (
    <div className="space-y-6">
      {/* Platform Selector */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-2xl font-bold text-gaming-dark mb-6">Select Platform</h3>
          <div className="flex flex-wrap gap-2">
            {platforms.map((platform) => (
              <Button
                key={platform.key}
                variant={selectedPlatform === platform.key ? "default" : "outline"}
                onClick={() => onPlatformChange(platform.key)}
                className={`px-6 py-3 font-semibold transition-all ${
                  selectedPlatform === platform.key
                    ? platform.key === "iPhone"
                      ? "bg-gaming-blue hover:bg-blue-700 text-white"
                      : platform.key === "Android"
                      ? "bg-gaming-green hover:bg-green-700 text-white"
                      : "bg-gaming-red hover:bg-red-700 text-white"
                    : "hover:bg-gray-100"
                }`}
              >
                <i className={`${platform.icon} mr-2`}></i>
                {platform.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Packages Grid */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-2xl font-bold text-gaming-dark mb-6">Available Packages</h3>
          
          {isLoading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <Skeleton className="h-8 w-24 mb-3" />
                    <Skeleton className="h-10 w-32 mb-3" />
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {error && (
            <div className="text-center py-8 text-red-600">
              <p>Failed to load coin packages. Please try again.</p>
            </div>
          )}

          {packages && packages.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Coins className="mx-auto h-12 w-12 mb-4" />
              <p>No packages available for {selectedPlatform}</p>
            </div>
          )}

          {packages && packages.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {packages.map((pkg) => (
                <Card
                  key={pkg.id}
                  className={`hover:shadow-lg transition-all cursor-pointer border-2 ${
                    selectedPlatform === "iPhone"
                      ? "bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200"
                      : selectedPlatform === "Android"
                      ? "bg-gradient-to-br from-green-50 to-green-100 border-green-200"
                      : "bg-gradient-to-br from-red-50 to-red-100 border-red-200"
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Coins className="text-gaming-gold mr-2 h-5 w-5" />
                        <span className="font-bold text-lg">{pkg.coins.toLocaleString()}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">Coins</Badge>
                    </div>
                    
                    <div className="text-center mb-3">
                      <span className={`text-2xl font-bold ${
                        selectedPlatform === "iPhone"
                          ? "text-gaming-blue"
                          : selectedPlatform === "Android"
                          ? "text-gaming-green"
                          : "text-gaming-red"
                      }`}>
                        {formatPrice(pkg.price)}
                      </span>
                    </div>
                    
                    <Button
                      onClick={() => handleAddToCart(pkg)}
                      className={`w-full transition-colors ${
                        selectedPlatform === "iPhone"
                          ? "bg-gaming-blue hover:bg-blue-700"
                          : selectedPlatform === "Android"
                          ? "bg-gaming-green hover:bg-green-700"
                          : "bg-gaming-red hover:bg-red-700"
                      }`}
                    >
                      <Plus className="mr-1 h-4 w-4" />
                      Add to Cart
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
