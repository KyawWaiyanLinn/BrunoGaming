import { Copy } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const PAYMENT_ACCOUNTS = [
  {
    method: "WAVEPAY",
    account: "09420749991",
    name: "Kyaw Wai Yan Linn",
    icon: "fas fa-wave-square",
    color: "purple",
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600"
  },
  {
    method: "KBZ Pay",
    account: "09965302618",
    name: "Win Ko Ko Aung",
    icon: "fas fa-university",
    color: "green",
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
  {
    method: "AYA PAY",
    account: "09965302618",
    name: "Win Ko Ko Aung",
    icon: "fas fa-wallet",
    color: "blue",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  {
    method: "AYA Bank",
    account: "20021667008",
    name: "Win Ko Ko Aung",
    icon: "fas fa-building",
    color: "red",
    bgColor: "bg-red-100",
    iconColor: "text-red-600"
  },
  {
    method: "KBZ BANK",
    account: "27730127700513901",
    name: "Win Ko Ko Aung",
    icon: "fas fa-university",
    color: "orange",
    bgColor: "bg-orange-100",
    iconColor: "text-orange-600"
  },
  {
    method: "CBPay",
    account: "27730127700513901",
    name: "Win Ko Ko Aung",
    icon: "fas fa-credit-card",
    color: "teal",
    bgColor: "bg-teal-100",
    iconColor: "text-teal-600"
  }
];

export default function PaymentAccounts() {
  const { toast } = useToast();

  const copyToClipboard = (text: string, method: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied!",
        description: `${method} account number copied to clipboard`,
      });
    });
  };

  return (
    <Card className="mt-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-bold text-gaming-dark mb-4">Payment Account Information</h3>
        <p className="text-sm text-gray-600 mb-6">Send payment to any of these accounts and contact us with transaction details</p>
        
        <div className="space-y-4">
          {PAYMENT_ACCOUNTS.map((account, index) => (
            <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className={`w-10 h-10 ${account.bgColor} rounded flex items-center justify-center mr-3`}>
                    <i className={`${account.icon} ${account.iconColor}`}></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gaming-dark">{account.method}</div>
                    <div className="text-sm text-gray-600">{account.name}</div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(account.account, account.method)}
                  className="text-xs"
                >
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
              
              <div className="bg-gray-50 rounded p-3">
                <div className="text-xs text-gray-500 mb-1">Account Number:</div>
                <div className="font-mono text-sm font-semibold text-gaming-dark">
                  {account.account}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-gaming-gold/10 rounded-lg border border-gaming-gold/20">
          <div className="flex items-start">
            <i className="fas fa-info-circle text-gaming-gold mr-2 mt-0.5"></i>
            <div className="text-sm">
              <div className="font-semibold text-gaming-dark mb-1">Payment Instructions:</div>
              <ul className="text-gray-600 space-y-1">
                <li>• Send payment to any account above</li>
                <li>• Take screenshot of transaction</li>
                <li>• Contact us with your order details</li>
                <li>• Coins will be delivered within 1-2 hours</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-4 text-center">
          <div className="text-sm text-gray-600">For support, contact:</div>
          <div className="font-semibold text-gaming-blue">09420749991</div>
          <div className="font-semibold text-gaming-blue">09965302618</div>
          <div className="text-sm text-gray-600">Available 24/7</div>
          <div className="text-xs text-gray-500 mt-1">Facebook: Kyaw Waiyan Linn</div>
        </div>
      </CardContent>
    </Card>
  );
}