import { Copy, CheckCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatPrice } from "@/lib/coin-data";

const PAYMENT_ACCOUNTS = [
  {
    method: "WAVEPAY",
    account: "09420749991",
    name: "Kyaw Wai Yan Linn",
    icon: "fas fa-wave-square",
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600"
  },
  {
    method: "KBZ Pay", 
    account: "09965302618",
    name: "Win Ko Ko Aung",
    icon: "fas fa-university",
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
  {
    method: "AYA PAY",
    account: "09965302618", 
    name: "Win Ko Ko Aung",
    icon: "fas fa-wallet",
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  {
    method: "AYA Bank",
    account: "20021667008",
    name: "Win Ko Ko Aung", 
    icon: "fas fa-building",
    bgColor: "bg-red-100",
    iconColor: "text-red-600"
  },
  {
    method: "KBZ BANK",
    account: "27730127700513901",
    name: "Win Ko Ko Aung", 
    icon: "fas fa-university",
    bgColor: "bg-orange-100",
    iconColor: "text-orange-600"
  },
  {
    method: "CBPay",
    account: "27730127700513901",
    name: "Win Ko Ko Aung", 
    icon: "fas fa-credit-card",
    bgColor: "bg-teal-100",
    iconColor: "text-teal-600"
  }
];

interface PaymentSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  totalAmount: number;
  selectedPaymentMethod: string;
}

export default function PaymentSuccessModal({ 
  isOpen, 
  onClose, 
  orderId, 
  totalAmount, 
  selectedPaymentMethod 
}: PaymentSuccessModalProps) {
  const { toast } = useToast();

  const copyToClipboard = (text: string, method: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied!",
        description: `${method} account number copied to clipboard`,
      });
    });
  };

  const copyOrderId = () => {
    navigator.clipboard.writeText(orderId).then(() => {
      toast({
        title: "Copied!",
        description: "Order ID copied to clipboard",
      });
    });
  };

  const selectedAccount = PAYMENT_ACCOUNTS.find(acc => 
    acc.method.toLowerCase().replace(' ', '-') === selectedPaymentMethod
  ) || PAYMENT_ACCOUNTS[0];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md w-full max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center text-xl font-bold text-gaming-dark">
            <CheckCircle className="text-green-600 mr-2" />
            Order Submitted Successfully!
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Order Details */}
          <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="text-sm text-gray-600 mb-1">Order ID:</div>
            <div className="flex items-center justify-center">
              <span className="font-mono font-semibold text-gaming-dark mr-2">
                #{orderId.slice(0, 8).toUpperCase()}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyOrderId}
                className="h-6 w-6 p-0"
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
            <div className="text-lg font-bold text-gaming-blue mt-2">
              Total: {formatPrice(totalAmount)}
            </div>
          </div>

          {/* Payment Instructions */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-bold text-gaming-dark mb-4">Complete Your Payment</h3>
              
              {/* Selected Payment Method */}
              <div className="border rounded-lg p-4 mb-4 bg-gaming-gold/5 border-gaming-gold/20">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 ${selectedAccount.bgColor} rounded flex items-center justify-center mr-3`}>
                      <i className={`${selectedAccount.icon} ${selectedAccount.iconColor}`}></i>
                    </div>
                    <div>
                      <div className="font-semibold text-gaming-dark">{selectedAccount.method}</div>
                      <div className="text-sm text-gray-600">{selectedAccount.name}</div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(selectedAccount.account, selectedAccount.method)}
                    className="text-xs"
                  >
                    <Copy className="h-3 w-3 mr-1" />
                    Copy
                  </Button>
                </div>
                
                <div className="bg-white rounded p-3 border">
                  <div className="text-xs text-gray-500 mb-1">Account Number:</div>
                  <div className="font-mono text-lg font-bold text-gaming-dark">
                    {selectedAccount.account}
                  </div>
                </div>
              </div>

              {/* Step by step instructions */}
              <div className="space-y-3">
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-gaming-blue text-white rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5">1</div>
                  <div className="text-sm">
                    <div className="font-semibold">Send Payment</div>
                    <div className="text-gray-600">Transfer {formatPrice(totalAmount)} to the account above</div>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-gaming-blue text-white rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5">2</div>
                  <div className="text-sm">
                    <div className="font-semibold">Take Screenshot</div>
                    <div className="text-gray-600">Capture transaction confirmation</div>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-gaming-blue text-white rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5">3</div>
                  <div className="text-sm">
                    <div className="font-semibold">Contact Us</div>
                    <div className="text-gray-600">Send screenshot + Order ID to confirm payment</div>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-gaming-green text-white rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5">4</div>
                  <div className="text-sm">
                    <div className="font-semibold">Receive Coins</div>
                    <div className="text-gray-600">Coins delivered within 1-2 hours</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="text-center p-4 bg-gaming-dark text-white rounded-lg">
            <div className="flex items-center justify-center mb-2">
              <Phone className="h-4 w-4 mr-2" />
              <span className="font-semibold">Contact Support</span>
            </div>
            <div className="font-bold text-gaming-gold">09420749991</div>
            <div className="font-bold text-gaming-gold">09965302618</div>
            <div className="text-sm text-gray-300 mt-2">Available 24/7 for payment confirmation</div>
            <div className="text-xs text-gray-300 mt-1">Facebook: Kyaw Waiyan Linn</div>
          </div>

          <Button
            onClick={onClose}
            className="w-full bg-gaming-blue hover:bg-blue-700 text-white"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}