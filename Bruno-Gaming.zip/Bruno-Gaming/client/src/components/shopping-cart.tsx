import { ShoppingCart, Trash2, Coins, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CartItem } from "@shared/schema";
import { formatPrice } from "@/lib/coin-data";

interface ShoppingCartProps {
  cart: CartItem[];
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
  onCheckout: () => void;
}

export default function ShoppingCartComponent({ cart, onRemoveItem, onClearCart, onCheckout }: ShoppingCartProps) {
  const totalAmount = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <Card className="sticky top-24">
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-gaming-dark mb-4 flex items-center">
          <ShoppingCart className="mr-2 text-gaming-gold" />
          Shopping Cart
        </h3>
        
        <div className="space-y-3 mb-6">
          {cart.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <ShoppingCart className="mx-auto h-12 w-12 mb-2 text-gray-300" />
              <p>Your cart is empty</p>
              <p className="text-sm">Add some coin packages to get started</p>
            </div>
          ) : (
            cart.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <Coins className="text-gaming-gold mr-2 h-4 w-4" />
                  <div>
                    <div className="font-semibold">{item.coins.toLocaleString()} Coins</div>
                    <div className="text-sm text-gray-600">{item.platform}</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="font-semibold mr-2">{formatPrice(item.price)}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveItem(index)}
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div>
            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <span className="font-semibold">Total:</span>
                <span className="text-xl font-bold text-gaming-blue">
                  {formatPrice(totalAmount)}
                </span>
              </div>
              
              <Button 
                onClick={onCheckout}
                className="w-full bg-gaming-gold hover:bg-yellow-500 text-gaming-dark font-bold mb-4"
              >
                <i className="fas fa-credit-card mr-2"></i>
                Proceed to Checkout
              </Button>

              <Button
                variant="outline"
                onClick={onClearCart}
                className="w-full text-gaming-dark hover:bg-gray-100"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Clear Cart
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
