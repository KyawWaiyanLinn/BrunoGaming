import React from 'react';

interface BrunoLogoProps {
  className?: string;
  size?: number;
}

export default function BrunoLogo({ className = "", size = 40 }: BrunoLogoProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background Circle */}
      <circle 
        cx="50" 
        cy="50" 
        r="45" 
        fill="url(#logoGradient)" 
        stroke="#FFD700" 
        strokeWidth="2"
      />
      
      {/* Letter B */}
      <path 
        d="M25 25 L25 75 L45 75 Q55 75 55 65 Q55 55 50 55 Q55 55 55 45 Q55 35 45 35 L25 35 Z M35 45 L45 45 M35 55 L45 55 M35 65 L45 65" 
        fill="none" 
        stroke="#FFFFFF" 
        strokeWidth="4" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
      
      {/* Gaming Controller Elements */}
      <circle cx="70" cy="30" r="3" fill="#FFD700" />
      <circle cx="80" cy="35" r="2" fill="#FFD700" />
      <circle cx="75" cy="40" r="2" fill="#FFD700" />
      
      {/* Football/Soccer Ball Pattern */}
      <circle cx="75" cy="70" r="8" fill="none" stroke="#FFD700" strokeWidth="2" />
      <path d="M70 65 L75 70 L80 65 M70 75 L75 70 L80 75" stroke="#FFD700" strokeWidth="1.5" fill="none" />
      
      {/* Gradient Definition */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3B82F6" />
          <stop offset="50%" stopColor="#1E40AF" />
          <stop offset="100%" stopColor="#1E3A8A" />
        </linearGradient>
      </defs>
    </svg>
  );
}