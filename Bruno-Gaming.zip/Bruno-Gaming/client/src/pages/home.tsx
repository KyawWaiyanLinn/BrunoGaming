import { useState } from "react";
import { Gamepad2, ShoppingCart, Phone, Mail, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import CoinPackages from "@/components/coin-packages";
import ShoppingCartComponent from "@/components/shopping-cart";
import CheckoutModal from "@/components/checkout-modal";
import PaymentAccounts from "@/components/payment-accounts";
import BrunoLogo from "@/components/bruno-logo";
import { CartItem } from "@shared/schema";

export default function Home() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState<string>("iPhone");
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const addToCart = (item: CartItem) => {
    setCart(prev => [...prev, item]);
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const clearCart = () => {
    setCart([]);
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gaming-dark text-white shadow-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BrunoLogo size={40} />
              <div>
                <h1 className="text-xl font-bold">Bruno Gaming</h1>
                <p className="text-sm text-gray-300">eFootball Coins Store</p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              className="relative bg-gaming-blue hover:bg-blue-700 text-white"
              onClick={() => setIsCheckoutOpen(true)}
              disabled={cart.length === 0}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Cart ({cart.length})
              {cart.length > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-gaming-gold text-gaming-dark">
                  {cart.length}
                </Badge>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gaming-blue to-gaming-green text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Get Your eFootball Coins</h2>
            <p className="text-xl mb-6 text-blue-100">Fast, secure, and reliable coin delivery for all platforms</p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="flex items-center">
                <i className="fas fa-check-circle text-gaming-gold mr-2"></i>
                <span>Instant Delivery</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-check-circle text-gaming-gold mr-2"></i>
                <span>Secure Payment</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-check-circle text-gaming-gold mr-2"></i>
                <span>24/7 Support</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="lg:w-2/3">
            <CoinPackages 
              selectedPlatform={selectedPlatform}
              onPlatformChange={setSelectedPlatform}
              onAddToCart={addToCart}
            />
          </div>

          {/* Sidebar */}
          <div className="lg:w-1/3">
            <ShoppingCartComponent 
              cart={cart}
              onRemoveItem={removeFromCart}
              onClearCart={clearCart}
              onCheckout={() => setIsCheckoutOpen(true)}
            />

            {/* Payment Account Information */}
            <PaymentAccounts />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gaming-dark text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <BrunoLogo size={32} className="mr-2" />
                <h3 className="text-lg font-bold">Bruno Gaming</h3>
              </div>
              <p className="text-gray-300 mb-4">Your trusted eFootball coins provider. Fast delivery, secure payments, and 24/7 customer support.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gaming-gold hover:text-yellow-400 text-xl">
                  <i className="fab fa-facebook"></i>
                </a>
                <a href="#" className="text-gaming-gold hover:text-yellow-400 text-xl">
                  <i className="fab fa-telegram"></i>
                </a>
                <a href="#" className="text-gaming-gold hover:text-yellow-400 text-xl">
                  <i className="fab fa-viber"></i>
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white">How to Order</a></li>
                <li><a href="#" className="hover:text-white">Payment Methods</a></li>
                <li><a href="#" className="hover:text-white">Delivery Process</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Contact Us</h3>
              <div className="space-y-2 text-gray-300">
                <p><Phone className="inline w-4 h-4 mr-2" />09420749991</p>
                <p><Phone className="inline w-4 h-4 mr-2" />09965302618</p>
                <p><Mail className="inline w-4 h-4 mr-2" />Kyawwaiyanlin334@gmail.com</p>
                <p><Clock className="inline w-4 h-4 mr-2" />24/7 Available</p>
                <p className="text-sm"><i className="fab fa-facebook mr-2"></i>Kyaw Waiyan Linn</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-300">
            <p>&copy; 2024 Bruno Gaming. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Checkout Modal */}
      <CheckoutModal 
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        totalAmount={totalAmount}
        onOrderComplete={() => {
          clearCart();
          setIsCheckoutOpen(false);
        }}
      />
    </div>
  );
}
