export const PLATFORMS = {
  iPhone: 'iPhone',
  Android: 'Android',
  Japan: 'Japan',
} as const;

export type Platform = keyof typeof PLATFORMS;

export const PAYMENT_METHODS = [
  { value: 'aya-pay', label: 'AYA PAY', icon: 'wallet' },
  { value: 'wave-money', label: 'Wave Money', icon: 'wave-square' },
  { value: 'kbz-pay', label: 'KBZ Pay', icon: 'university' },
  { value: 'aya-bank', label: 'AYA Bank', icon: 'building' },
] as const;

export const ORDER_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
} as const;

export function formatPrice(price: number): string {
  return price.toLocaleString() + ' Ks';
}

export function getPlatformColor(platform: string): string {
  switch (platform) {
    case 'iPhone':
      return 'gaming-blue';
    case 'Android':
      return 'gaming-green';
    case 'Japan':
      return 'gaming-red';
    default:
      return 'gaming-blue';
  }
}

export function getPlatformIcon(platform: string): string {
  switch (platform) {
    case 'iPhone':
      return 'fab fa-apple';
    case 'Android':
      return 'fab fa-android';
    case 'Japan':
      return 'fas fa-flag';
    default:
      return 'fas fa-gamepad';
  }
}
