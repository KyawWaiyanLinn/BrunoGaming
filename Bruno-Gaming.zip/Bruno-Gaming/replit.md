# Bruno Gaming - eFootball Coins Store

## Overview

This is a modern React-based e-commerce application for selling eFootball game coins. The application provides a clean interface for browsing coin packages across different platforms (iPhone, Android, Japan), managing a shopping cart, and processing orders. It's built with TypeScript and follows modern web development best practices.

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## System Architecture

The application follows a full-stack architecture with clear separation between client and server:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom gaming theme variables
- **State Management**: TanStack Query for server state, React hooks for local state
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Storage**: DatabaseStorage class with persistent PostgreSQL storage
- **API Design**: RESTful endpoints with JSON responses
- **Validation**: Zod schemas shared between client and server

## Key Components

### Data Layer
- **Database Schema**: Defined in `shared/schema.ts` using Drizzle ORM
- **Tables**: 
  - `coin_packages`: Stores coin package data (platform, coins, price)
  - `orders`: Stores order information with customer details and items
- **Storage Interface**: Abstracted storage layer with DatabaseStorage using PostgreSQL for persistence

### Frontend Components
- **CoinPackages**: Displays available coin packages with platform filtering
- **ShoppingCart**: Manages cart state and displays selected items
- **CheckoutModal**: Handles order form and submission
- **UI Components**: Complete set of reusable components from shadcn/ui

### API Endpoints
- `GET /api/coin-packages`: Fetch all coin packages
- `GET /api/coin-packages/:platform`: Fetch packages by platform
- `POST /api/orders`: Create new order

## Data Flow

1. **Package Display**: Client fetches coin packages from API based on selected platform
2. **Cart Management**: Items added to local cart state using React hooks
3. **Order Processing**: Form submission validates data and sends to API
4. **Database Storage**: Orders stored in PostgreSQL with customer and item details

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling and validation
- **zod**: Runtime type validation
- **@radix-ui/***: Accessible UI primitives

### Development Tools
- **Vite**: Build tool and dev server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first styling
- **ESBuild**: Production bundling for server

## Deployment Strategy

### Development
- **Server**: Runs on `tsx` for TypeScript execution
- **Client**: Vite dev server with HMR
- **Database**: Neon serverless PostgreSQL
- **Environment**: NODE_ENV=development

### Production
- **Build Process**: 
  1. Vite builds client to `dist/public`
  2. ESBuild bundles server to `dist/index.js`
- **Runtime**: Node.js with compiled JavaScript
- **Static Assets**: Served by Express in production
- **Database**: Same Neon instance with production credentials

### Configuration
- **Database**: Configured via `DATABASE_URL` environment variable
- **Build Output**: Client assets in `dist/public`, server in `dist/index.js`
- **Path Aliases**: Configured for clean imports (`@/`, `@shared/`)

### Gaming Theme
The application uses a custom gaming-focused design system with specific color variables for different platforms (iPhone/blue, Android/green, Japan/red) and includes gaming-specific UI elements like coin icons and themed cards.